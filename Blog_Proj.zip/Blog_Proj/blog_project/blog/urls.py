from django.urls import path
from .views import PostListView, PostDetailView, UserRegistrationView, ObtainTokenView

urlpatterns = [
    path('posts/', PostListView.as_view(), name='post-list'),
    path('posts/<int:id>/', PostDetailView.as_view(), name='post-detail'),
    path('register/', UserRegistrationView.as_view(), name='user-register'),
    path('login/', ObtainTokenView.as_view(), name='user-login'),
]
